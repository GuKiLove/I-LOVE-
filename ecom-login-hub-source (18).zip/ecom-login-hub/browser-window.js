const { BrowserWindow, session, ipcMain } = require('electron');
const path = require('path');
const cookieMgr = require('./cookie-manager');

const chromeUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
const wins = {};

// 各平台登录成功后必有的Cookie
const LOGIN_COOKIES = {
  taobao:       { domain: 'taobao.com',      names: ['cookie2', 'unb', '_samesite_flag_'] },
  jd:           { domain: 'jd.com',          names: ['pin', 'pt_key', 'thor'] },
  pdd:          { domain: 'pinduoduo.com',   names: ['PDDAccessToken', 'pdd_user_id'] },
  douyin:       { domain: 'jinritemai.com',  names: ['sessionid'] },
  kuaishou:     { domain: 'kuaishou.com',    names: ['userId', 'kuaishou.server.web.at'] },
  taogongchang: { domain: 'tmall.com',       names: ['cookie2', 'unb'] },
};

function createBrowserWindow(platform, startUrl) {
  const platformId = platform.platformId || platform.id;
  const accountId  = platform.accountId;
  const sessionKey = accountId ? `${platformId}_${accountId}` : platformId;

  if (wins[sessionKey] && !wins[sessionKey].isDestroyed()) {
    wins[sessionKey].focus();
    // 淘宝系用独立窗口，不能 send new-tab
    if (!['taobao', 'taogongchang'].includes(platformId)) {
      wins[sessionKey].webContents.send('new-tab', { url: startUrl });
    }
    return;
  }

  // 淘宝/淘工厂：千牛基于 Electron 内核，webview 嵌套会冲突，改用独立窗口直接加载
  if (['taobao', 'taogongchang'].includes(platformId)) {
    createDirectWindow(platform, startUrl, platformId, accountId, sessionKey);
    return;
  }

  const ses = session.fromPartition(`persist:${sessionKey}`);

  ses.webRequest.onHeadersReceived((details, callback) => {
    const h = { ...details.responseHeaders };
    // 移除所有安全限制，确保千牛等页面正常渲染
    delete h['content-security-policy'];
    delete h['Content-Security-Policy'];
    delete h['x-frame-options'];
    delete h['X-Frame-Options'];
    delete h['x-content-type-options'];
    delete h['X-Content-Type-Options'];
    // 允许跨域
    h['access-control-allow-origin'] = ['*'];
    callback({ responseHeaders: h });
  });

  ses.cookies.on('changed', () => ses.cookies.flushStore().catch(() => {}));

  const win = new BrowserWindow({
    width: 1280, height: 860,
    minWidth: 900, minHeight: 600,
    title: platformId + ' - 商家后台',
    backgroundColor: '#2d2d2d',
    show: false,
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      webSecurity: false,
      allowRunningInsecureContent: true,
      webviewTag: true,
      backgroundThrottling: false,
      plugins: true,
    },
  });

  win.setMenuBarVisibility(false);
  win.once('ready-to-show', () => win.show());

  let notified = false;

  // ── 核心：定时轮询Cookie检测登录状态 ──────────────────────
  const rule = LOGIN_COOKIES[platformId];

  async function checkCookie() {
    if (notified || !rule) return false;
    try {
      const all = await ses.cookies.get({});
      const names = all.map(c => c.name);
      const hit = rule.names.find(n => names.includes(n));
      if (!hit) return false;

      notified = true;
      console.log('[登录成功]', platformId, accountId, '| Cookie命中:', hit);

      // 保存Cookie到文件
      await cookieMgr.saveCookies(sessionKey).catch(() => {});

      // 通知主界面更新状态
      const mainWin = BrowserWindow.getAllWindows().find(w => w !== win && !w.isDestroyed());
      if (mainWin) {
        mainWin.webContents.send('login-success', { platformId, accountId, shopName: '', userName: '' });
      }
      return true;
    } catch(e) {
      console.log('[Cookie检测错误]', e.message);
      return false;
    }
  }

  // 每秒检测一次，最多5分钟
  let count = 0;
  const timer = setInterval(async () => {
    count++;
    if (count > 300 || notified) { clearInterval(timer); return; }
    const ok = await checkCookie();
    if (ok) clearInterval(timer);
  }, 1000);

  win.on('close', () => {
    clearInterval(timer);
    cookieMgr.saveCookies(sessionKey).catch(() => {});
  });

  win.on('closed', () => {
    delete wins[sessionKey];
    // 关窗口时如果还没成功，重置状态
    if (!notified) {
      const mainWin = BrowserWindow.getAllWindows().find(w => !w.isDestroyed());
      if (mainWin) {
        mainWin.webContents.send('login-window-closed', { platformId, accountId });
      }
    }
  });

  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));

  win.loadFile(path.join(__dirname, 'browser.html'));

  win.webContents.on('did-finish-load', () => {
    win.webContents.send('browser-init', {
      platform: { ...platform, _platformId: platformId, _sessionKey: sessionKey },
      startUrl: startUrl || platform.shopUrl || platform.loginUrl,
      chromeUA,
    });
  });

  wins[sessionKey] = win;
}

// 淘宝/淘工厂专用：直接用 BrowserWindow 加载，不经过 webview
function createDirectWindow(platform, startUrl, platformId, accountId, sessionKey) {
  const ses = session.fromPartition(`persist:${sessionKey}`);

  ses.webRequest.onHeadersReceived((details, callback) => {
    const h = { ...details.responseHeaders };
    delete h['content-security-policy'];
    delete h['Content-Security-Policy'];
    delete h['x-frame-options'];
    delete h['X-Frame-Options'];
    h['access-control-allow-origin'] = ['*'];
    callback({ responseHeaders: h });
  });

  ses.cookies.on('changed', () => ses.cookies.flushStore().catch(() => {}));

  const win = new BrowserWindow({
    width: 1280, height: 860,
    minWidth: 900, minHeight: 600,
    title: platformId + ' - 商家后台',
    backgroundColor: '#fff',
    show: false,
    autoHideMenuBar: true,
    webPreferences: {
      partition: `persist:${sessionKey}`,
      webSecurity: false,
      allowRunningInsecureContent: true,
      contextIsolation: false,
      nodeIntegration: false,
      backgroundThrottling: false,
    },
  });

  win.setMenuBarVisibility(false);
  win.webContents.setUserAgent(chromeUA);
  win.once('ready-to-show', () => win.show());

  // 所有新窗口在当前窗口内打开
  win.webContents.setWindowOpenHandler(({ url }) => {
    win.webContents.loadURL(url, { userAgent: chromeUA });
    return { action: 'deny' };
  });

  let notified = false;
  const rule = LOGIN_COOKIES[platformId];

  async function checkCookie() {
    if (notified || !rule) return false;
    try {
      const all = await ses.cookies.get({});
      const names = all.map(c => c.name);
      const hit = rule.names.find(n => names.includes(n));
      if (!hit) return false;
      notified = true;
      cookieMgr.saveCookies(sessionKey).catch(() => {});
      const mainWin = BrowserWindow.getAllWindows().find(w => w !== win && !w.isDestroyed());
      if (mainWin) {
        mainWin.webContents.send('login-success', { platformId, accountId, shopName: '', userName: '' });
      }
      return true;
    } catch(e) { return false; }
  }

  let count = 0;
  const timer = setInterval(async () => {
    if (++count > 300 || notified) { clearInterval(timer); return; }
    if (await checkCookie()) clearInterval(timer);
  }, 1000);

  win.on('close', () => {
    clearInterval(timer);
    cookieMgr.saveCookies(sessionKey).catch(() => {});
  });

  win.on('closed', () => {
    delete wins[sessionKey];
    if (!notified) {
      const mainWin = BrowserWindow.getAllWindows().find(w => !w.isDestroyed());
      if (mainWin) mainWin.webContents.send('login-window-closed', { platformId, accountId });
    }
  });

  win.loadURL(startUrl || platform.loginUrl, { userAgent: chromeUA });
  wins[sessionKey] = win;
}

module.exports = { createBrowserWindow, chromeUA };
