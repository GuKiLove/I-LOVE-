(function () {
  if (document.getElementById('__nav__')) return;

  // 导航栏容器
  var bar = document.createElement('div');
  bar.id = '__nav__';
  bar.style.cssText = [
    'position:fixed', 'top:0', 'left:0', 'right:0', 'z-index:2147483647',
    'height:44px', 'background:#1a1d28',
    'display:flex', 'align-items:center', 'gap:4px', 'padding:0 8px',
    'box-shadow:0 2px 8px rgba(0,0,0,.5)',
    'font-family:-apple-system,PingFang SC,Microsoft YaHei,sans-serif',
  ].join(';');

  function btn(text, title, bg) {
    var b = document.createElement('button');
    b.textContent = text;
    b.title = title;
    b.style.cssText = [
      'width:34px', 'height:32px', 'border-radius:7px', 'border:none',
      'background:' + (bg || 'rgba(255,255,255,.08)'),
      'color:' + (bg ? '#fff' : '#9aa0a6'),
      'font-size:16px', 'cursor:pointer', 'flex-shrink:0',
      'display:flex', 'align-items:center', 'justify-content:center',
      'transition:background .12s',
    ].join(';');
    b.onmouseover = function () { b.style.background = bg ? 'rgba(239,68,68,.7)' : 'rgba(255,255,255,.18)'; };
    b.onmouseout  = function () { b.style.background = bg || 'rgba(255,255,255,.08)'; };
    return b;
  }

  var backBtn    = btn('←', '后退');
  var fwdBtn     = btn('→', '前进');
  var refreshBtn = btn('↺', '刷新');

  // 地址栏
  var urlBar = document.createElement('div');
  urlBar.style.cssText = [
    'flex:1', 'height:30px', 'background:rgba(255,255,255,.08)',
    'border-radius:15px', 'display:flex', 'align-items:center',
    'padding:0 12px', 'gap:6px',
    'border:1px solid rgba(255,255,255,.1)',
    'cursor:text', 'overflow:hidden',
  ].join(';');

  var urlIcon = document.createElement('span');
  urlIcon.style.cssText = 'font-size:12px;flex-shrink:0;color:#9aa0a6;';
  urlIcon.textContent = location.protocol === 'https:' ? '🔒' : '🌐';

  var urlText = document.createElement('span');
  urlText.style.cssText = 'flex:1;font-size:12px;color:#bdc1c6;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;';
  urlText.textContent = location.href;

  urlBar.appendChild(urlIcon);
  urlBar.appendChild(urlText);

  var closeBtn = btn('✕', '关闭窗口', 'rgba(239,68,68,.15)');
  closeBtn.style.color = '#ef4444';
  closeBtn.style.width = '34px';

  bar.appendChild(backBtn);
  bar.appendChild(fwdBtn);
  bar.appendChild(refreshBtn);
  bar.appendChild(urlBar);
  bar.appendChild(closeBtn);
  document.documentElement.prepend(bar);

  // 给页面让出导航栏高度
  var st = document.createElement('style');
  st.textContent = 'html{margin-top:44px !important;}';
  document.head.appendChild(st);

  // 按钮事件
  backBtn.onclick    = function () { history.back(); };
  fwdBtn.onclick     = function () { history.forward(); };
  refreshBtn.onclick = function () { location.reload(); };
  closeBtn.onclick   = function () { window.close(); };

  // 定时同步 URL
  var last = '';
  setInterval(function () {
    if (location.href !== last) {
      last = location.href;
      urlText.textContent = last;
      urlIcon.textContent = location.protocol === 'https:' ? '🔒' : '🌐';
    }
  }, 300);
})();
