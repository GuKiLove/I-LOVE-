# 电商聚合登录管理系统

## 快速启动

### 环境要求
- Node.js 18+ （下载：https://nodejs.org）
- Windows / macOS / Linux

### 安装依赖
```bash
npm install
```

### 开发模式运行
```bash
npm start
```

### 打包成桌面应用
```bash
npm run build
```
打包后文件在 `dist/` 目录：
- Windows：`dist/电商聚合登录 Setup 1.0.0.exe`
- macOS：`dist/电商聚合登录-1.0.0.dmg`
- Linux：`dist/电商聚合登录-1.0.0.AppImage`

## 功能说明
- 支持 7 个主流电商平台：淘宝、天猫、京东、拼多多、抖音小店、快手小店、淘工厂
- 账号统一管理：添加、编辑、删除账号
- 一键登录 / 批量刷新过期账号
- 桌面版支持应用内嵌窗口登录（Cookie 独立隔离）
- 登录状态实时检测
