const { contextBridge, ipcRenderer } = require('electron');

// 安全地暴露 Electron API 给 React 前端
contextBridge.exposeInMainWorld('electronAPI', {
  // 打开登录窗口（走登录流程）
  openLoginWindow: (platform) =>
    ipcRenderer.invoke('open-login-window', platform),

  // 打开商家后台（已登录时直接进后台，复用 Cookie）
  openShopWindow: (platform) =>
    ipcRenderer.invoke('open-shop-window', platform),

  // 在系统默认浏览器中打开链接
  openExternal: (url) =>
    ipcRenderer.invoke('open-external', url),

  // Cookie 管理
  clearCookies: (platformId) =>
    ipcRenderer.invoke('clear-cookies', platformId),

  getCookies: (platformId, domain) =>
    ipcRenderer.invoke('get-cookies', { platformId, domain }),

  closeLoginWindow: (platformId) =>
    ipcRenderer.invoke('close-login-window', platformId),

  // 监听主进程事件
  onLoginSuccess: (callback) => {
    ipcRenderer.on('login-success', (event, data) => callback(data));
    return () => ipcRenderer.removeAllListeners('login-success');
  },

  onLoginWindowClosed: (callback) => {
    ipcRenderer.on('login-window-closed', (event, data) => callback(data));
    return () => ipcRenderer.removeAllListeners('login-window-closed');
  },

  // Cookie 失效通知（打开店铺后被重定向到登录页）
  onCookieExpired: (callback) => {
    ipcRenderer.on('cookie-expired', (event, data) => callback(data));
    return () => ipcRenderer.removeAllListeners('cookie-expired');
  },

  // 窗口控制
  minimize: () => ipcRenderer.send('window-minimize'),
  maximize: () => ipcRenderer.send('window-maximize'),
  close:    () => ipcRenderer.send('window-close'),

  // 判断当前是否在 Electron 环境
  isElectron: true,
});
