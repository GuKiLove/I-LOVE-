const { app, BrowserWindow, ipcMain, session, shell, Menu, Tray, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');
// 性能优化：启用GPU加速、禁用不必要的特性
app.commandLine.appendSwitch('enable-gpu-rasterization');
app.commandLine.appendSwitch('enable-zero-copy');
app.commandLine.appendSwitch('disable-http-cache', 'false');
app.commandLine.appendSwitch('js-flags', '--max-old-space-size=512');
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-background-timer-throttling');
app.commandLine.appendSwitch('disable-backgrounding-occluded-windows');

const cookieMgr = require('./cookie-manager');
const { createBrowserWindow } = require('./browser-window');
const isDev = !app.isPackaged;

// 必须在 app ready 前设置，确保 session 数据写入固定的 userData 目录
// 这样关闭软件重启后 Cookie 仍然存在，无需重新登录
app.setPath('userData', path.join(app.getPath('appData'), 'ecom-login-hub'));

let mainWindow;
let tray;
const loginWindows = {}; // 存储各平台的登录子窗口

// ── 创建主窗口 ─────────────────────────────────────────────
function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 960,
    minHeight: 640,
    title: '博创电商聚合登录系统',
    backgroundColor: '#0c0e14',
    frame: false,
    titleBarStyle: 'hidden',
    titleBarOverlay: {
      color: '#13151e',
      symbolColor: '#8892b0',
      height: 40,
    },
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true,
      backgroundThrottling: false,   // 关闭后台节流，保持响应
      v8CacheOptions: 'bypassHeatCheck', // V8脚本缓存加速
    },
    show: false,
  });

  // 加载页面
  const startUrl = isDev
    ? 'http://localhost:3000'
    : require('url').format({
        pathname: path.join(__dirname, 'build', 'index.html'),
        protocol: 'file:',
        slashes: true,
      });

  mainWindow.loadURL(startUrl);

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    if (isDev) mainWindow.webContents.openDevTools({ mode: 'detach' });
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // 拦截外部链接，在系统浏览器中打开
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

// ── 创建平台内嵌登录窗口 ─────────────────────────────────
function createLoginWindow(platform) {
  // 如果该平台窗口已存在，聚焦即可
  if (loginWindows[platform.id] && !loginWindows[platform.id].isDestroyed()) {
    loginWindows[platform.id].focus();
    return;
  }

  // 每个平台使用独立 session，Cookie 互不干扰
  const partitionSession = session.fromPartition(`persist:${platform.id}`);

  // 移除所有 CSP 限制，允许平台页面正常加载图片、脚本、二维码等资源
  partitionSession.webRequest.onHeadersReceived((details, callback) => {
    const headers = { ...details.responseHeaders };
    delete headers['content-security-policy'];
    delete headers['Content-Security-Policy'];
    delete headers['x-frame-options'];
    delete headers['X-Frame-Options'];
    callback({ responseHeaders: headers });
  });

  const chromeUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

  const win = new BrowserWindow({
    width: 1280,
    height: 840,
    minWidth: 960,
    minHeight: 640,
    title: `${platform.name} - 商家后台`,
    backgroundColor: '#fff',
    modal: false,
    webPreferences: {
      contextIsolation: false,
      nodeIntegration: false,
      partition: `persist:${platform.id}`,
      webSecurity: false,
      allowRunningInsecureContent: true,
      images: true,
      javascript: true,
    },
  });

  win.webContents.setUserAgent(chromeUA);

  // 禁止弹出新窗口，所有链接在当前窗口内打开
  win.webContents.setWindowOpenHandler(({ url }) => {
    win.loadURL(url, { userAgent: chromeUA });
    return { action: 'deny' };
  });

  // 注入顶部导航栏（后退/前进/刷新/地址栏/关闭）
  const navbarScript = require('fs').readFileSync(
    require('path').join(__dirname, 'inject-navbar.js'), 'utf8'
  );
  function injectNavBar() {
    win.webContents.executeJavaScript(navbarScript).catch(() => {});
  }
  win.webContents.on('did-finish-load', injectNavBar);

  win.loadURL(platform.loginUrl, { userAgent: chromeUA });

  win.on('close', () => { session.fromPartition(`persist:${platform.id}`).cookies.flushStore().catch(()=>{}); });
  win.on('closed', () => {
    delete loginWindows[platform.id];
    // 通知主窗口该平台登录窗口已关闭（可能已完成登录）
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('login-window-closed', { platformId: platform.id });
    }
  });

  // ── 登录成功检测（两步验证，避免误判）──────────────────────
  // 规则：必须先经过登录页，再跳转到后台首页，才算真正登录成功
  // 登录成功URL匹配规则（覆盖各平台扫码/密码登录后的跳转地址）
  const PLATFORM_RULES = {
    taobao:       { success: ['myseller.taobao.com/home', 'myseller.taobao.com/QnworkbenchHome', 'myseller.taobao.com/main', 'myseller.taobao.com/sellerDetail'] },
    jd:           { success: ['jingmai.jd.com', 'shop.jd.com/jdm', 'shop.jd.com/index', 'shop.jd.com/home', 'shop.jd.com/view', 'jdsz.jd.com', 'jzt.jd.com', 'jinmai.jd.com'] },
    pdd:          { success: ['mms.pinduoduo.com/home', 'mms.pinduoduo.com/goods', 'mms.pinduoduo.com/index', 'mms.pinduoduo.com/dashboard'] },
    douyin:       { success: ['fxg.jinritemai.com/index', 'fxg.jinritemai.com/goods', 'fxg.jinritemai.com/home', 'fxg.jinritemai.com/product'] },
    kuaishou:     { success: ['s.kwaixiaodian.com/index', 's.kwaixiaodian.com/goods', 's.kwaixiaodian.com/home', 's.kwaixiaodian.com/supply'] },
    taogongchang: { success: ['tgcwork.tmall.com/index', 'tgcwork.tmall.com/home', 'tgcwork.tmall.com/dashboard', 'tgc.taobao.com/index'] },
  };
  // 登录成功检测：同时监听普通跳转 + 单页跳转（扫码登录走单页跳转）
  const windowOpenTime = Date.now();
  const MIN_LOGIN_WAIT_MS = 1500; // 等待1.5秒避免初始重定向误判
  let loginNotified = false; // 只通知一次

  function checkLoginSuccess(url) {
    if (loginNotified) return;
    const rules = PLATFORM_RULES[platform.id];
    if (!rules) return;
    // 无论是否超过等待时间，都打印URL方便调试
    const elapsed = Date.now() - windowOpenTime;
    console.log('[' + platform.id + '] 跳转:', url, '| 已等待:', elapsed + 'ms');
    if (elapsed < MIN_LOGIN_WAIT_MS) return;
    const matched = rules.success.find(u => url.includes(u));
    if (matched) {
      console.log('[' + platform.id + '] 命中规则:', matched);
    }
    if (matched) {
      loginNotified = true;
      console.log('[' + platform.id + '] 登录成功:', url);
      cookieMgr.saveCookies(platform.id);

      // 各平台店铺信息抓取规则
      const shopInfoRules = {
        taobao:       { name: ['#shop-name', '.shop-name', '[class*="shopName"]', 'title'], user: ['.member-nick', '#user-name'] },
        jd:           { name: ['title', '.shop-name', '[class*="shopName"]', '.merchant-name'], user: ['.user-name', '.login-name', '[class*="userName"]'] },
        pdd:          { name: ['.shop-name', '[class*="shopName"]', 'title'], user: ['.user-name', '[class*="userName"]'] },
        douyin:       { name: ['.shop-name', '[class*="shopName"]', 'title'], user: ['[class*="userName"]', '.user-name'] },
        kuaishou:     { name: ['.shop-name', 'title'], user: ['.user-name', '[class*="userName"]'] },
        taogongchang: { name: ['title', '.shop-name'], user: ['.user-name'] },
      };

      // 延迟抓取，等页面完全渲染
      setTimeout(async () => {
        try {
          const rules = shopInfoRules[platform.id];
          if (!rules) return;

          // 抓取店铺名
          let shopName = '';
          for (const sel of rules.name) {
            try {
              const js = sel === 'title'
                ? 'document.title || ""'
                : '(function(){ var el = document.querySelector("' + sel + '"); return el ? (el.innerText || el.textContent || "").trim() : ""; })()';
              const result = await win.webContents.executeJavaScript(js);
              if (result && result.length > 0 && result.length < 50) {
                shopName = result; break;
              }
            } catch(e) {}
          }

          // 抓取账号
          let userName = '';
          for (const sel of rules.user) {
            try {
              const js = '(function(){ var el = document.querySelector("' + sel + '"); return el ? (el.innerText || el.textContent || "").trim() : ""; })()';
              const result = await win.webContents.executeJavaScript(js);
              if (result && result.length > 0 && result.length < 30) {
                userName = result; break;
              }
            } catch(e) {}
          }

          console.log('[店铺信息]', platform.id, '店铺名:', shopName, '账号:', userName);

          if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.webContents.send('login-success', {
              platformId: platform.id,
              shopName: shopName || '',
              userName: userName || '',
            });
          }
        } catch(e) {
          console.log('[店铺信息] 抓取失败:', e.message);
          if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.webContents.send('login-success', { platformId: platform.id });
          }
        }
      }, 2000);
    }
  }

  // 普通页面跳转（账号密码登录）
  win.webContents.on('did-navigate', (event, url) => checkLoginSuccess(url));
  // 单页内跳转（扫码登录、Ajax跳转）
  win.webContents.on('did-navigate-in-page', (event, url) => checkLoginSuccess(url));

  loginWindows[platform.id] = win;
}

// ── Cookie 管理 ────────────────────────────────────────────
async function getCookiesForPlatform(platformId, domain) {
  try {
    const ses = session.fromPartition(`persist:${platformId}`);
    const cookies = await ses.cookies.get({ domain });
    return cookies;
  } catch (e) {
    return [];
  }
}

async function clearCookiesForPlatform(platformId) {
  try {
    const ses = session.fromPartition(`persist:${platformId}`);
    await ses.clearStorageData({ storages: ['cookies', 'localstorage', 'sessionstorage'] });
    return true;
  } catch (e) {
    return false;
  }
}

// ── IPC 通信 ───────────────────────────────────────────────
ipcMain.handle('open-login-window', (event, platform) => {
  // platform 包含 accountId（账号唯一ID）和 platformId（平台标识）
  createBrowserWindow(platform, platform.loginUrl);
});

ipcMain.handle('open-shop-window', (event, platform) => {
  createBrowserWindow(platform, platform.shopUrl || platform.loginUrl);
});


ipcMain.handle('open-external', (event, url) => {
  shell.openExternal(url);
});

ipcMain.handle('clear-cookies', async (event, platformId) => {
  return await clearCookiesForPlatform(platformId);
});

ipcMain.handle('get-cookies', async (event, { platformId, domain }) => {
  return await getCookiesForPlatform(platformId, domain);
});

ipcMain.handle('close-login-window', (event, platformId) => {
  if (loginWindows[platformId] && !loginWindows[platformId].isDestroyed()) {
    loginWindows[platformId].close();
  }
});

// 窗口控制（无边框模式）
ipcMain.on('window-minimize', () => mainWindow?.minimize());
ipcMain.on('window-maximize', () => {
  if (mainWindow?.isMaximized()) mainWindow.unmaximize();
  else mainWindow?.maximize();
});
ipcMain.on('window-close', () => mainWindow?.close());

// ── 系统托盘 ──────────────────────────────────────────────
function createTray() {
  // 用文字生成简单图标（实际项目替换为真实 icon 文件）
  const icon = nativeImage.createEmpty();
  tray = new Tray(icon);
  tray.setToolTip('电商聚合登录管理');
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: '显示主窗口', click: () => mainWindow?.show() },
    { type: 'separator' },
    { label: '退出', click: () => app.quit() },
  ]));
  tray.on('double-click', () => mainWindow?.show());
}

// ── App 生命周期 ───────────────────────────────────────────
app.whenReady().then(() => {
  createMainWindow();

  const platformIds = ['taobao', 'jd', 'pdd', 'douyin', 'kuaishou', 'taogongchang'];

  // 启动时先从文件恢复所有平台的 Cookie
  // 启动时从cookie目录读取所有已保存的sessionKey并恢复
  try {
    const cookieDir = require('path').join(app.getPath('userData'), 'cookies');
    if (require('fs').existsSync(cookieDir)) {
      const keys = require('fs').readdirSync(cookieDir)
        .filter(f => f.endsWith('.json'))
        .map(f => f.replace('.json', ''));
      console.log('[启动] 恢复Cookie keys:', keys);
      if (keys.length > 0) {
        cookieMgr.loadAll(keys).then(() => console.log('[启动] Cookie恢复完成'));
      }
    }
  } catch(e) {
    cookieMgr.loadAll(['taobao','jd','pdd','douyin','kuaishou','taogongchang']);
  }
  // 应用启动时，对所有平台 session 开启 Cookie 持久化
  platformIds.forEach(id => {
    const ses = session.fromPartition(`persist:${id}`);
    // Cookie 变更时立即写盘
    ses.cookies.on('changed', (event, cookie, cause, removed) => {
      ses.cookies.flushStore().catch(() => {});
    });
    // 移除 CSP 限制
    ses.webRequest.onHeadersReceived((details, callback) => {
      const headers = { ...details.responseHeaders };
      delete headers['content-security-policy'];
      delete headers['Content-Security-Policy'];
      delete headers['x-frame-options'];
      delete headers['X-Frame-Options'];
      callback({ responseHeaders: headers });
    });
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
  });

  // 全局拦截：所有新创建的 webContents（包括 webview 内部弹窗）
  // 如果是从商家后台 webview 弹出的新窗口，转发给对应标签页处理
  app.on('web-contents-created', (event, contents) => {
    // 拦截 webview 内的新窗口请求
    contents.setWindowOpenHandler(({ url }) => {
      // 找到该 webContents 所属的浏览器窗口，发送 new-tab 消息
      const allWins = BrowserWindow.getAllWindows();
      for (const win of allWins) {
        if (win.webContents.id !== contents.id) {
          try {
            win.webContents.send('new-tab', { url });
            break;
          } catch(e) {}
        }
      }
      return { action: 'deny' }; // 阻止弹出新窗口
    });
  });
});

// 应用退出前，把所有平台 Cookie 保存到文件，确保下次启动免登录
app.on('before-quit', async (event) => {
  event.preventDefault();
  const ids = ['taobao', 'jd', 'pdd', 'douyin', 'kuaishou', 'taogongchang'];
  await cookieMgr.saveAll(ids);
  console.log('[Cookie] 所有平台 Cookie 已保存到文件');
  app.exit(0);
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// 单例模式：防止多开
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
}
