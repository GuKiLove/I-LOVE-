const { session, app } = require('electron');
const path = require('path');
const fs = require('fs');

const COOKIE_DIR = path.join(app.getPath('userData'), 'cookies');

// 确保目录存在
function ensureDir() {
  if (!fs.existsSync(COOKIE_DIR)) fs.mkdirSync(COOKIE_DIR, { recursive: true });
}

// 把某平台的 Cookie 导出保存到文件
async function saveCookies(platformId) {
  try {
    ensureDir();
    const ses = session.fromPartition(`persist:${platformId}`);
    await ses.cookies.flushStore();
    const cookies = await ses.cookies.get({});
    const filePath = path.join(COOKIE_DIR, `${platformId}.json`);
    fs.writeFileSync(filePath, JSON.stringify(cookies, null, 2), 'utf8');
    console.log(`[Cookie] ${platformId} 已保存 ${cookies.length} 条`);
  } catch (e) {
    console.error(`[Cookie] 保存失败 ${platformId}:`, e.message);
  }
}

// 把保存的 Cookie 注入回 session
async function loadCookies(platformId) {
  try {
    ensureDir();
    const filePath = path.join(COOKIE_DIR, `${platformId}.json`);
    if (!fs.existsSync(filePath)) return;
    const cookies = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    const ses = session.fromPartition(`persist:${platformId}`);
    for (const cookie of cookies) {
      try {
        await ses.cookies.set({
          url: `https://${cookie.domain.replace(/^\./, '')}`,
          name: cookie.name,
          value: cookie.value,
          domain: cookie.domain,
          path: cookie.path || '/',
          secure: cookie.secure || false,
          httpOnly: cookie.httpOnly || false,
          expirationDate: cookie.expirationDate,
          sameSite: cookie.sameSite || 'no_restriction',
        });
      } catch (e) {}
    }
    await ses.cookies.flushStore();
    console.log(`[Cookie] ${platformId} 已恢复 ${cookies.length} 条`);
  } catch (e) {
    console.error(`[Cookie] 恢复失败 ${platformId}:`, e.message);
  }
}

// 保存所有平台
async function saveAll(platformIds) {
  await Promise.all(platformIds.map(id => saveCookies(id)));
}

// 恢复所有平台
async function loadAll(platformIds) {
  await Promise.all(platformIds.map(id => loadCookies(id)));
}

module.exports = { saveCookies, loadCookies, saveAll, loadAll };
