import { useState, useEffect, useCallback } from "react";

// ─── 检测是否在 Electron 环境 ────────────────────────────
const isElectron = typeof window !== "undefined" && !!window.electronAPI;
const api = isElectron ? window.electronAPI : null;

// 本地持久化：Electron 用主进程文件存储，网页用 localStorage
const storage = {
  save: (key, data) => {
    try {
      if (isElectron && api.saveData) {
        api.saveData(key, JSON.stringify(data));
      } else {
        localStorage.setItem(key, JSON.stringify(data));
      }
    } catch(e) {}
  },
  load: (key) => {
    try {
      if (isElectron && api.loadData) {
        return api.loadData(key);
      } else {
        const v = localStorage.getItem(key);
        return v ? JSON.parse(v) : null;
      }
    } catch(e) { return null; }
  },
};

// ─── 平台配置 ─────────────────────────────────────────────
const PLATFORMS = [
  // 淘宝卖家工作台（未登录会自动跳登录页）
  { id: "taobao",       name: "淘宝卖家",   color: "#FF4400", glow: "#FF440044", icon: "🛒", domain: "taobao.com",       loginUrl: "https://loginmyseller.taobao.com/?from=&f=top&style=&sub=true&redirect_url=https%3A%2F%2Fmyseller.taobao.com%2Fhome.htm%2FQnworkbenchHome%2F", shopUrl: "https://myseller.taobao.com/home.htm/QnworkbenchHome/", desc: "淘宝卖家工作台" },

  // 京东京麦商家工作台（正确地址）
  { id: "jd",           name: "京东商家",   color: "#D9000D", glow: "#D9000D44", icon: "🏪", domain: "jd.com",           loginUrl: "https://passport.shop.jd.com/login/index.action/jdm?ReturnUrl=https%3A%2F%2Fshop.jd.com", shopUrl: "https://shop.jd.com/jdm/home", desc: "京东京麦商家工作台" },
  // 拼多多商家管理后台
  { id: "pdd",          name: "拼多多商家", color: "#C0392B", glow: "#C0392B44", icon: "🛍️", domain: "pinduoduo.com",   loginUrl: "https://mms.pinduoduo.com", shopUrl: "https://mms.pinduoduo.com/home", desc: "拼多多商家管理后台" },
  // 抖音电商商家后台（抖店）
  { id: "douyin",       name: "抖音小店",   color: "#1890FF", glow: "#1890FF44", icon: "🎵", domain: "jinritemai.com",   loginUrl: "https://fxg.jinritemai.com", shopUrl: "https://fxg.jinritemai.com/index", desc: "抖音电商商家后台" },
  // 快手小店商家后台
  { id: "kuaishou",     name: "快手小店",   color: "#FF4906", glow: "#FF490644", icon: "⚡", domain: "kwaixiaodian.com", loginUrl: "https://s.kwaixiaodian.com", shopUrl: "https://s.kwaixiaodian.com/index", desc: "快手小店商家后台" },
  // 淘工厂供应商商家后台
  { id: "taogongchang", name: "淘工厂",     color: "#FF6A00", glow: "#FF6A0044", icon: "🏭", domain: "tmall.com",        loginUrl: "https://tgcwork.tmall.com", shopUrl: "https://tgcwork.tmall.com", desc: "淘工厂供应商后台" },
];

const INIT_ACCOUNTS = [];

const STATUS_CFG = {
  active:   { label: "已登录", color: "#22c55e", bg: "rgba(34,197,94,0.12)" },
  expired:  { label: "已过期", color: "#f59e0b", bg: "rgba(245,158,11,0.12)" },
  inactive: { label: "未登录", color: "#6b7280", bg: "rgba(107,114,128,0.12)" },
  logging:  { label: "登录中", color: "#3b82f6", bg: "rgba(59,130,246,0.12)" },
};

function getPlatform(id) { return PLATFORMS.find(p => p.id === id) || PLATFORMS[0]; }

// ─── 子组件 ───────────────────────────────────────────────
function StatusBadge({ status }) {
  const cfg = STATUS_CFG[status] || STATUS_CFG.inactive;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: "3px 9px", borderRadius: 20,
      background: cfg.bg, color: cfg.color,
      fontSize: 12, fontWeight: 600, whiteSpace: "nowrap",
    }}>
      <span style={{
        width: 6, height: 6, borderRadius: "50%", background: cfg.color,
        boxShadow: status === "active" ? `0 0 6px ${cfg.color}` : "none",
        animation: status === "logging" ? "pulse 1s infinite" : "none",
      }} />
      {cfg.label}
    </span>
  );
}

function Toggle({ value, onChange }) {
  return (
    <div onClick={() => onChange(!value)} style={{
      width: 42, height: 24, borderRadius: 12, cursor: "pointer",
      background: value ? "#f97316" : "#2e3140",
      position: "relative", transition: "background 0.2s", flexShrink: 0,
    }}>
      <div style={{
        width: 18, height: 18, borderRadius: "50%", background: "#fff",
        position: "absolute", top: 3, left: value ? 21 : 3,
        transition: "left 0.2s", boxShadow: "0 1px 4px rgba(0,0,0,0.3)",
      }} />
    </div>
  );
}

// ─── 颜色常量 ─────────────────────────────────────────────
const C = {
  bg: "#0c0e14", surface: "#13151e", surface2: "#1a1d28",
  border: "#22263a", border2: "#2a2f45",
  text: "#e2e6f3", textSub: "#8892b0", textMute: "#4a5270",
  accent: "#f97316", accentSoft: "rgba(249,115,22,0.12)",
};

export default function App() {
  // 启动时从本地加载已保存的账号，没有才用示例数据
  const [accounts, setAccounts] = useState(() => {
    try {
      const saved = localStorage.getItem('ecom_accounts');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch(e) {}
    return INIT_ACCOUNTS;
  });
  const [view, setView]                 = useState("list");
  const [filterPlatform, setFilterPlatform] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [searchText, setSearchText]     = useState("");
  const [time, setTime]                 = useState(new Date());
  const [toast, setToast]               = useState(null);
  const [expandedId, setExpandedId]     = useState(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState(null);
  const [loginProgress, setLoginProgress]   = useState({});
  const [editTarget, setEditTarget]     = useState(null);
  const [settings, setSettings]         = useState({
    autoRefresh: true, rememberCookie: true,
    openInApp: isElectron, notifyExpiry: true,
  });
  const [form, setForm] = useState({ platform: "taobao", shopName: "", username: "", note: "" });

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  // accounts 任何变化都自动持久化到本地
  useEffect(() => {
    try {
      localStorage.setItem('ecom_accounts', JSON.stringify(accounts));
    } catch(e) {}
  }, [accounts]);

  // 监听 Electron 主进程事件
  useEffect(() => {
    if (!api) return;
    const offSuccess = api.onLoginSuccess(({ platformId, accountId, shopName, userName }) => {
      setAccounts(prev => prev.map(a => {
        // 优先用 accountId 精确匹配，没有则按平台匹配
        const match = accountId
          ? String(a.id) === String(accountId)
          : a.platform === platformId;
        if (!match) return a;
        const updates = { status: "active", lastLogin: "刚刚" };
        if (shopName && shopName.length > 0 && shopName.length < 50) {
          updates.shopName = shopName;
        }
        if (userName && userName.length > 0 && userName.length < 30) {
          updates.username = userName;
        }
        return { ...a, ...updates };
      }));
      setLoginProgress(prev => { const n = { ...prev }; delete n[platformId]; return n; });
      showToast("登录成功 ✓");
    });
    const offClosed = api.onLoginWindowClosed(({ platformId, accountId }) => {
      setAccounts(prev => prev.map(a => {
        // 用 accountId 精确匹配，没有则按平台匹配
        const match = accountId
          ? String(a.id) === String(accountId)
          : a.platform === platformId && a.status === "logging";
        if (!match) return a;
        // 只重置还在"登录中"的账号
        if (a.status !== "logging") return a;
        return { ...a, status: "inactive" };
      }));
      setLoginProgress(prev => { const n = { ...prev }; delete n[platformId]; return n; });
    });

    // Cookie 失效：打开店铺后被跳到登录页，自动更新状态为过期
    const offExpired = api.onCookieExpired && api.onCookieExpired(({ platformId }) => {
      setAccounts(prev => prev.map(a =>
        a.platform === platformId && a.status === "active"
          ? { ...a, status: "expired", note: "Cookie已失效，请重新登录" } : a
      ));
      showToast("登录已过期，请重新扫码登录", "error");
    });
    return () => { offSuccess?.(); offClosed?.(); };
  }, []);

  function showToast(msg, type = "success") {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 2800);
  }

  // ── 登录逻辑 ────────────────────────────────────────────
  async function handleLogin(account) {
    if (account.status === "logging") return;
    const p = getPlatform(account.platform);

    setAccounts(prev => prev.map(a =>
      a.id === account.id ? { ...a, status: "logging" } : a
    ));
    setLoginProgress(prev => ({ ...prev, [account.id]: 0 }));

    if (isElectron && settings.openInApp) {
      // Electron 内嵌窗口登录
      await api.openLoginWindow({ ...p, accountId: account.id, platformId: account.platform });
      // 进度条动画
      let pct = 0;
      const iv = setInterval(() => {
        pct = Math.min(pct + 8, 85);
        setLoginProgress(prev => ({ ...prev, [account.id]: pct }));
        if (pct >= 85) clearInterval(iv);
      }, 200);
    } else {
      // 网页/外部浏览器模式：模拟进度 + 打开浏览器
      if (isElectron) api.openExternal(p.loginUrl);
      else window.open(p.loginUrl, "_blank");

      let pct = 0;
      const iv = setInterval(() => {
        pct += Math.random() * 20 + 8;
        if (pct >= 100) {
          clearInterval(iv);
          setLoginProgress(prev => { const n = { ...prev }; delete n[account.id]; return n; });
          setAccounts(prev => prev.map(a =>
            a.id === account.id ? { ...a, status: "active", lastLogin: "刚刚" } : a
          ));
          showToast(`${account.shopName} 登录成功 ✓`);
        } else {
          setLoginProgress(prev => ({ ...prev, [account.id]: Math.min(pct, 92) }));
        }
      }, 300);
    }
  }

  async function handleLogout(account) {
    if (isElectron) {
      await api.clearCookies(account.platform);
      await api.closeLoginWindow(account.platform);
    }
    setAccounts(prev => prev.map(a =>
      a.id === account.id ? { ...a, status: "inactive", lastLogin: "刚刚退出" } : a
    ));
    showToast(`${account.shopName} 已退出`, "info");
  }

  // 已登录时直接打开商家后台，复用已保存的 Cookie 不需要重新登录
  function handleOpenShop(account) {
    const p = getPlatform(account.platform);
    if (isElectron) {
      api.openShopWindow({ ...p, accountId: account.id, platformId: account.platform });
    } else {
      window.open(p.shopUrl || p.loginUrl, "_blank");
    }
  }

  function handleBatchLogin() {
    const targets = accounts.filter(a => a.status === "expired" || a.status === "inactive");
    targets.forEach((acc, i) => setTimeout(() => handleLogin(acc), i * 900));
    showToast(`开始批量登录 ${targets.length} 个账号`);
  }

  function handleSaveForm() {
    if (!form.shopName.trim() || !form.username.trim()) {
      showToast("请填写店铺名称和账号", "error"); return;
    }
    if (editTarget) {
      setAccounts(prev => prev.map(a => a.id === editTarget.id ? { ...a, ...form } : a));
      showToast("账号信息已更新");
    } else {
      setAccounts(prev => [...prev, {
        id: Date.now(), ...form, status: "inactive", lastLogin: "从未登录",
      }]);
      showToast(`${form.shopName} 添加成功`);
    }
    setEditTarget(null);
    setForm({ platform: "taobao", shopName: "", username: "", note: "" });
    setView("list");
  }

  function openEdit(acc) {
    setEditTarget(acc);
    setForm({ platform: acc.platform, shopName: acc.shopName, username: acc.username, note: acc.note || "" });
    setView("add");
  }

  function handleDelete(id) {
    setAccounts(prev => prev.filter(a => a.id !== id));
    setDeleteConfirmId(null);
    showToast("账号已删除", "info");
  }

  // ── 过滤 ────────────────────────────────────────────────
  const filtered = accounts.filter(a => {
    if (filterPlatform !== "all" && a.platform !== filterPlatform) return false;
    if (filterStatus   !== "all" && a.status   !== filterStatus)   return false;
    if (searchText && !a.shopName.includes(searchText) && !a.username.includes(searchText)) return false;
    return true;
  });

  const activeCount  = accounts.filter(a => a.status === "active").length;
  const expiredCount = accounts.filter(a => a.status === "expired").length;

  // ── 样式 helper ─────────────────────────────────────────
  const btn = {
    primary: { padding: "9px 18px", borderRadius: 9, border: "none", background: "linear-gradient(135deg,#f97316,#ef4444)", color: "#fff", fontSize: 13, fontWeight: 700, cursor: "pointer", boxShadow: "0 2px 12px #f9731630" },
    ghost:   { padding: "8px 14px", borderRadius: 9, border: `1px solid ${C.border2}`, background: "transparent", color: C.textSub, fontSize: 13, cursor: "pointer" },
    danger:  { padding: "8px 14px", borderRadius: 9, border: "none", background: "rgba(239,68,68,0.12)", color: "#ef4444", fontSize: 13, fontWeight: 600, cursor: "pointer" },
    sm:      (color) => ({ padding: "6px 12px", borderRadius: 7, border: "none", fontSize: 12, fontWeight: 600, cursor: "pointer", background: color + "18", color }),
    login:   (status) => ({
      padding: "7px 16px", borderRadius: 8, border: "none", fontSize: 12, fontWeight: 700, cursor: status === "logging" ? "not-allowed" : "pointer", whiteSpace: "nowrap", transition: "all 0.15s",
      background: status === "active" ? "rgba(34,197,94,0.12)" : status === "logging" ? "rgba(59,130,246,0.12)" : "linear-gradient(135deg,#f97316,#ef4444)",
      color:      status === "active" ? "#22c55e" : status === "logging" ? "#3b82f6" : "#fff",
    }),
  };

  const card = { background: C.surface, borderRadius: 12, border: `1px solid ${C.border}`, overflow: "hidden" };
  const inputStyle = { width: "100%", padding: "10px 12px", background: C.surface2, border: `1px solid ${C.border2}`, borderRadius: 9, color: C.text, fontSize: 13, outline: "none", boxSizing: "border-box" };

  // ── 渲染 ────────────────────────────────────────────────
  return (
    <div style={{ fontFamily: "'PingFang SC','Microsoft YaHei',sans-serif", background: C.bg, minHeight: "100vh", display: "flex", flexDirection: "column", color: C.text }}>
      <style>{`
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
        @keyframes slideUp{from{opacity:0;transform:translateX(-50%) translateY(8px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}
        input::placeholder{color:#4a5270}
        select option{background:#13151e}
        *::-webkit-scrollbar{width:4px}
        *::-webkit-scrollbar-thumb{background:#2a2f45;border-radius:2px}
        button:hover{filter:brightness(1.1)}
      `}</style>

      {/* ── 标题栏 ── */}
      <div style={{ height: 52, background: C.surface, borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", padding: "0 20px", gap: 12, flexShrink: 0, WebkitAppRegion: "drag" }}>
        <div style={{ width: 28, height: 28, borderRadius: 8, background: "linear-gradient(135deg,#f97316,#ef4444)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15, flexShrink: 0 }}>🛒</div>
        <span style={{ fontWeight: 800, fontSize: 14, color: "#fff" }}>博创电商聚合登录</span>
        {isElectron && <span style={{ fontSize: 11, color: C.textMute, background: C.surface2, padding: "2px 7px", borderRadius: 4 }}>桌面版</span>}

        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 16, WebkitAppRegion: "no-drag" }}>
          <span style={{ fontSize: 12, color: "#22c55e", display: "flex", alignItems: "center", gap: 5 }}>
            <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#22c55e", boxShadow: "0 0 6px #22c55e", display: "inline-block" }} />
            {activeCount} 已登录
          </span>
          {expiredCount > 0 && (
            <span style={{ fontSize: 12, color: "#f59e0b" }}>⚠ {expiredCount} 过期</span>
          )}
          <span style={{ fontSize: 12, color: C.textMute, fontVariantNumeric: "tabular-nums" }}>
            {time.toLocaleTimeString("zh-CN")}
          </span>
          {/* 原生标题栏按钮（Electron titleBarOverlay 会覆盖此区域） */}
          {isElectron && (
            <div style={{ display: "flex", gap: 6, marginLeft: 8 }}>
              {[["─", () => api.minimize()], ["□", () => api.maximize()], ["✕", () => api.close()]].map(([label, fn], i) => (
                <button key={i} onClick={fn} style={{ width: 28, height: 22, borderRadius: 4, border: "none", background: C.surface2, color: C.textSub, fontSize: 11, cursor: "pointer" }}>{label}</button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>
        {/* ── 侧边栏 ── */}
        <div style={{ width: 210, background: C.surface, borderRight: `1px solid ${C.border}`, display: "flex", flexDirection: "column", flexShrink: 0 }}>
          <div style={{ padding: "14px 12px 6px" }}>
            <div style={{ fontSize: 10, color: C.textMute, fontWeight: 700, letterSpacing: 1.5, padding: "0 8px", marginBottom: 6 }}>账号状态</div>
            {[
              { key: "all",      label: "全部账号", count: accounts.length,                                   icon: "📋", status: "all" },
              { key: "active",   label: "已登录",   count: activeCount,                                       icon: "🟢", status: "active" },
              { key: "expired",  label: "已过期",   count: expiredCount,                                      icon: "🟡", status: "expired" },
              { key: "inactive", label: "未登录",   count: accounts.filter(a=>a.status==="inactive").length,  icon: "⚪", status: "inactive" },
            ].map(item => {
              const active = filterStatus === item.status && filterPlatform === "all";
              return (
                <div key={item.key} onClick={() => { setFilterStatus(item.status); setFilterPlatform("all"); setView("list"); }}
                  style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 10px", borderRadius: 8, cursor: "pointer", marginBottom: 2, background: active ? C.accentSoft : "transparent", color: active ? C.accent : C.textSub, fontSize: 13, fontWeight: active ? 600 : 400 }}>
                  <span style={{ fontSize: 12 }}>{item.icon}</span>
                  <span style={{ flex: 1 }}>{item.label}</span>
                  <span style={{ fontSize: 11, background: C.surface2, padding: "1px 7px", borderRadius: 10 }}>{item.count}</span>
                </div>
              );
            })}
          </div>

          <div style={{ padding: "12px 12px 6px", borderTop: `1px solid ${C.border}`, marginTop: 8 }}>
            <div style={{ fontSize: 10, color: C.textMute, fontWeight: 700, letterSpacing: 1.5, padding: "0 8px", marginBottom: 6 }}>按平台筛选</div>
            {PLATFORMS.map(p => {
              const cnt = accounts.filter(a => a.platform === p.id).length;
              const active = filterPlatform === p.id;
              return (
                <div key={p.id} onClick={() => { setFilterPlatform(p.id); setFilterStatus("all"); setView("list"); }}
                  style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 10px", borderRadius: 8, cursor: "pointer", marginBottom: 2, borderLeft: active ? `3px solid ${p.color}` : "3px solid transparent", background: active ? `${p.color}10` : "transparent", color: active ? p.color : C.textSub, fontSize: 13 }}>
                  <span>{p.icon}</span>
                  <span style={{ flex: 1 }}>{p.name}</span>
                  <span style={{ fontSize: 11, opacity: 0.7 }}>{cnt}</span>
                </div>
              );
            })}
          </div>

          <div style={{ flex: 1 }} />
          <div style={{ padding: "10px 12px 14px", borderTop: `1px solid ${C.border}` }}>
            <div onClick={() => setView("settings")}
              style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 10px", borderRadius: 8, cursor: "pointer", color: view === "settings" ? C.accent : C.textSub, background: view === "settings" ? C.accentSoft : "transparent", fontSize: 13 }}>
              <span>⚙️</span><span>系统设置</span>
            </div>
          </div>
        </div>

        {/* ── 主内容区 ── */}
        <div style={{ flex: 1, overflow: "auto", padding: 24 }}>

          {/* 列表页 */}
          {view === "list" && (
            <div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }}>
                <div style={{ fontSize: 18, fontWeight: 700, color: "#fff" }}>
                  登录账号管理
                  <span style={{ fontSize: 13, color: C.textMute, fontWeight: 400, marginLeft: 10 }}>{filtered.length} 个账号</span>
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  {(expiredCount > 0) && (
                    <button style={{ ...btn.ghost, color: "#f59e0b", borderColor: "#f59e0b40" }} onClick={handleBatchLogin}>
                      ⚡ 批量刷新过期 ({expiredCount})
                    </button>
                  )}
                  <button style={btn.primary} onClick={() => { setEditTarget(null); setForm({ platform: "taobao", shopName: "", username: "", note: "" }); setView("add"); }}>
                    + 添加账号
                  </button>
                </div>
              </div>

              {/* 搜索栏 */}
              <div style={{ display: "flex", gap: 10, marginBottom: 14 }}>
                <div style={{ flex: 1, position: "relative" }}>
                  <span style={{ position: "absolute", left: 11, top: "50%", transform: "translateY(-50%)", color: C.textMute, fontSize: 14 }}>🔍</span>
                  <input style={{ ...inputStyle, paddingLeft: 32 }} placeholder="搜索店铺名称或账号..." value={searchText} onChange={e => setSearchText(e.target.value)} />
                </div>
                <select style={{ ...inputStyle, width: "auto", cursor: "pointer" }} value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
                  <option value="all">全部状态</option>
                  <option value="active">已登录</option>
                  <option value="expired">已过期</option>
                  <option value="inactive">未登录</option>
                </select>
              </div>

              {/* 平台快捷入口 */}
              <div style={{ display: "flex", gap: 8, marginBottom: 18, flexWrap: "wrap" }}>
                {PLATFORMS.map(p => (
                  <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 5, padding: "5px 11px", borderRadius: 7, cursor: "pointer", background: C.surface, border: `1px solid ${C.border}`, fontSize: 12, color: C.textSub, transition: "all 0.15s" }}
                    onClick={() => isElectron ? api.openExternal(p.loginUrl) : window.open(p.loginUrl, "_blank")}
                    onMouseEnter={e => { e.currentTarget.style.borderColor = p.color + "60"; e.currentTarget.style.color = p.color; }}
                    onMouseLeave={e => { e.currentTarget.style.borderColor = C.border; e.currentTarget.style.color = C.textSub; }}>
                    {p.icon} {p.name} <span style={{ fontSize: 10, opacity: 0.6 }}>↗</span>
                  </div>
                ))}
              </div>

              {/* 账号表格 */}
              <div style={card}>
                {/* 表头 */}
                <div style={{ display: "grid", gridTemplateColumns: "2fr 1.3fr 1fr 1fr 1fr 1.5fr", padding: "10px 18px", background: C.surface2, borderBottom: `1px solid ${C.border}`, fontSize: 11, color: C.textMute, fontWeight: 700, letterSpacing: 0.5 }}>
                  <span>店铺信息</span><span>平台</span><span>状态</span><span>上次登录</span><span>备注</span><span>操作</span>
                </div>

                {filtered.length === 0 && (
                  <div style={{ padding: 48, textAlign: "center", color: C.textMute }}>
                    <div style={{ fontSize: 32, marginBottom: 8 }}>🔍</div>
                    <div>暂无匹配账号</div>
                  </div>
                )}

                {filtered.map(acc => {
                  const p = getPlatform(acc.platform);
                  const isExpanded = expandedId === acc.id;
                  const pct = loginProgress[acc.id];
                  return (
                    <div key={acc.id}>
                      {/* 行 */}
                      <div style={{ display: "grid", gridTemplateColumns: "2fr 1.3fr 1fr 1fr 1fr 1.5fr", padding: "13px 18px", borderBottom: `1px solid ${C.border}18`, background: isExpanded ? `${C.accent}06` : "transparent", alignItems: "center", cursor: "pointer" }}
                        onClick={() => setExpandedId(isExpanded ? null : acc.id)}>

                        {/* 店铺信息 */}
                        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                          <div style={{ width: 34, height: 34, borderRadius: 9, background: `${p.color}22`, border: `1.5px solid ${p.color}50`, color: p.color, fontSize: 14, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                            {acc.shopName[0]}
                          </div>
                          <div>
                            <div style={{ fontSize: 13, fontWeight: 600, color: "#fff" }}>{acc.shopName}</div>
                            <div style={{ fontSize: 11, color: C.textMute, marginTop: 1 }}>@{acc.username}</div>
                          </div>
                        </div>

                        {/* 平台标签 */}
                        <div>
                          <span style={{ display: "inline-flex", alignItems: "center", gap: 4, padding: "2px 8px", borderRadius: 6, background: p.color + "18", color: p.color, border: `1px solid ${p.color}30`, fontSize: 11, fontWeight: 700 }}>
                            {p.icon} {p.name}
                          </span>
                        </div>

                        {/* 状态 */}
                        <div>
                          <StatusBadge status={acc.status} />
                          {pct !== undefined && (
                            <div style={{ height: 3, borderRadius: 2, background: `linear-gradient(90deg, ${p.color} ${pct}%, #2a2f45 ${pct}%)`, marginTop: 5, transition: "all 0.3s" }} />
                          )}
                        </div>

                        <div style={{ fontSize: 12, color: C.textMute }}>{acc.lastLogin}</div>
                        <div style={{ fontSize: 12, color: acc.note ? "#f59e0b" : C.textMute }}>{acc.note || "—"}</div>

                        {/* 操作按钮 */}
                        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }} onClick={e => e.stopPropagation()}>
                          {acc.status === "active" ? (
                            <>
                              <button style={{ ...btn.login("active"), background: "linear-gradient(135deg,#f97316,#ef4444)", color: "#fff" }}
                                onClick={() => handleOpenShop(acc)}>
                                🏪 打开店铺
                              </button>
                              <button style={{ ...btn.ghost, padding: "7px 10px", fontSize: 12, color: "#ef4444", borderColor: "#ef444430" }}
                                onClick={() => handleLogout(acc)}>退出</button>
                            </>
                          ) : (
                            <button style={btn.login(acc.status)} onClick={() => handleLogin(acc)}>
                              {acc.status === "logging" ? "登录中…" : "立即登录"}
                            </button>
                          )}
                          <button style={{ ...btn.ghost, padding: "6px 10px", fontSize: 13 }} title="编辑" onClick={() => openEdit(acc)}>✏️</button>
                          <button style={{ ...btn.ghost, padding: "6px 10px", fontSize: 13, color: "#ef4444", borderColor: "#ef444430" }} title="删除" onClick={() => setDeleteConfirmId(acc.id)}>🗑</button>
                        </div>
                      </div>

                      {/* 展开详情 */}
                      {isExpanded && (
                        <div style={{ background: C.surface2, borderBottom: `1px solid ${C.border}18`, padding: "16px 18px" }}>
                          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginBottom: 14 }}>
                            {[
                              { label: "平台", value: `${p.icon} ${p.name}` },
                              { label: "账号", value: `@${acc.username}` },
                              { label: "状态", value: STATUS_CFG[acc.status]?.label },
                              { label: "上次登录", value: acc.lastLogin },
                              { label: "备注", value: acc.note || "无" },
                              { label: "登录地址", value: p.loginUrl, url: true },
                            ].map((item, i) => (
                              <div key={i} style={{ background: C.surface, borderRadius: 8, padding: "10px 12px", border: `1px solid ${C.border}` }}>
                                <div style={{ fontSize: 10, color: C.textMute, marginBottom: 4, fontWeight: 600 }}>{item.label}</div>
                                {item.url ? (
                                  <span style={{ fontSize: 12, color: p.color, cursor: "pointer", wordBreak: "break-all" }}
                                    onClick={() => isElectron ? api.openExternal(p.loginUrl) : window.open(p.loginUrl, "_blank")}>
                                    {item.value} ↗
                                  </span>
                                ) : (
                                  <div style={{ fontSize: 13, color: C.text }}>{item.value}</div>
                                )}
                              </div>
                            ))}
                          </div>
                          <div style={{ display: "flex", gap: 8 }}>
                            {acc.status === "active" ? (
                              <>
                                <button style={btn.primary} onClick={() => handleOpenShop(acc)}>🏪 打开店铺后台</button>
                                <button style={btn.danger} onClick={() => handleLogout(acc)}>退出登录</button>
                              </>
                            ) : (
                              <button style={btn.primary} onClick={() => handleLogin(acc)}>
                                {acc.status === "logging" ? "登录中…" : "立即登录"}
                              </button>
                            )}
                            <button style={btn.ghost} onClick={() => openEdit(acc)}>编辑账号</button>
                            <button style={{ ...btn.danger, background: "transparent", border: "1px solid #ef444430" }} onClick={() => setDeleteConfirmId(acc.id)}>删除账号</button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* 底部统计 */}
              <div style={{ display: "flex", gap: 20, marginTop: 14, paddingTop: 12, borderTop: `1px solid ${C.border}`, fontSize: 12, color: C.textMute }}>
                <span>共 <b style={{ color: C.text }}>{accounts.length}</b> 个账号</span>
                <span>已登录 <b style={{ color: "#22c55e" }}>{activeCount}</b></span>
                <span>过期 <b style={{ color: "#f59e0b" }}>{expiredCount}</b></span>
                <span>未登录 <b style={{ color: C.textMute }}>{accounts.filter(a=>a.status==="inactive").length}</b></span>
              </div>
            </div>
          )}

          {/* 添加/编辑页 */}
          {view === "add" && (
            <div style={{ maxWidth: 500 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
                <button style={btn.ghost} onClick={() => { setView("list"); setEditTarget(null); }}>← 返回</button>
                <div style={{ fontSize: 18, fontWeight: 700, color: "#fff" }}>{editTarget ? "编辑账号" : "添加新账号"}</div>
              </div>

              <div style={card}>
                <div style={{ padding: 24 }}>
                  {/* 平台选择 */}
                  <div style={{ marginBottom: 18 }}>
                    <div style={{ fontSize: 12, color: C.textMute, marginBottom: 8, fontWeight: 600 }}>选择平台 *</div>
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8 }}>
                      {PLATFORMS.map(pl => {
                        const sel = form.platform === pl.id;
                        return (
                          <div key={pl.id} onClick={() => setForm(f => ({ ...f, platform: pl.id }))}
                            style={{ padding: "10px 6px", borderRadius: 9, cursor: "pointer", textAlign: "center", border: `1.5px solid ${sel ? pl.color : C.border}`, background: sel ? `${pl.color}12` : C.surface2, transition: "all 0.15s" }}>
                            <div style={{ fontSize: 22, marginBottom: 3 }}>{pl.icon}</div>
                            <div style={{ fontSize: 11, fontWeight: 600, color: sel ? pl.color : C.textSub }}>{pl.name}</div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* 已选平台提示 */}
                  {(() => { const p = getPlatform(form.platform); return (
                    <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 14px", borderRadius: 8, background: `${p.color}10`, border: `1px solid ${p.color}30`, marginBottom: 16 }}>
                      <span style={{ fontSize: 18 }}>{p.icon}</span>
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 600, color: p.color }}>{p.name}</div>
                        <span style={{ fontSize: 11, color: C.textMute, cursor: "pointer" }}
                          onClick={() => isElectron ? api.openExternal(p.loginUrl) : window.open(p.loginUrl, "_blank")}>
                          {p.loginUrl} ↗
                        </span>
                      </div>
                    </div>
                  ); })()}

                  {[
                    { key: "shopName", label: "店铺名称 *", placeholder: "例：我的旗舰店" },
                    { key: "username", label: "登录账号 *", placeholder: "手机号 / 用户名 / 邮箱" },
                    { key: "note",     label: "备注（可选）", placeholder: "如：主账号、备用号…" },
                  ].map(field => (
                    <div key={field.key} style={{ marginBottom: 14 }}>
                      <div style={{ fontSize: 12, color: C.textMute, marginBottom: 6, fontWeight: 600 }}>{field.label}</div>
                      <input style={inputStyle} placeholder={field.placeholder}
                        value={form[field.key]}
                        onChange={e => setForm(f => ({ ...f, [field.key]: e.target.value }))} />
                    </div>
                  ))}

                  <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
                    <button style={{ ...btn.primary, flex: 1 }} onClick={handleSaveForm}>
                      {editTarget ? "保存修改" : "确认添加"}
                    </button>
                    <button style={btn.ghost} onClick={() => { setView("list"); setEditTarget(null); }}>取消</button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 设置页 */}
          {view === "settings" && (
            <div style={{ maxWidth: 520 }}>
              <div style={{ fontSize: 18, fontWeight: 700, color: "#fff", marginBottom: 20 }}>系统设置</div>
              {[
                { title: "🔑 登录行为", items: [
                  { key: "autoRefresh",    label: "自动检测登录状态", desc: "定时检测各账号 Cookie 是否仍有效" },
                  { key: "rememberCookie", label: "记住 Cookie 状态", desc: "本地缓存登录状态，减少重复登录" },
                  { key: "openInApp",      label: "应用内嵌窗口登录", desc: isElectron ? "在应用内打开平台页面（桌面版可用）" : "仅桌面版支持此功能" },
                ]},
                { title: "🔔 通知提醒", items: [
                  { key: "notifyExpiry", label: "登录过期提醒", desc: "Cookie 失效时推送系统通知" },
                ]},
              ].map((group, gi) => (
                <div key={gi} style={{ ...card, marginBottom: 14 }}>
                  <div style={{ padding: "13px 20px", borderBottom: `1px solid ${C.border}`, fontSize: 13, fontWeight: 700, color: C.text }}>{group.title}</div>
                  {group.items.map((item, ii) => (
                    <div key={item.key} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "13px 20px", borderBottom: ii < group.items.length - 1 ? `1px solid ${C.border}18` : "none" }}>
                      <div>
                        <div style={{ fontSize: 13, color: C.text, marginBottom: 2 }}>{item.label}</div>
                        <div style={{ fontSize: 11, color: C.textMute }}>{item.desc}</div>
                      </div>
                      <Toggle value={settings[item.key]} onChange={v => setSettings(s => ({ ...s, [item.key]: v }))} />
                    </div>
                  ))}
                </div>
              ))}

              <div style={card}>
                <div style={{ padding: "13px 20px", borderBottom: `1px solid ${C.border}`, fontSize: 13, fontWeight: 700, color: C.text }}>ℹ️ 关于</div>
                <div style={{ padding: "16px 20px" }}>
                  <div style={{ fontSize: 13, color: C.textSub, lineHeight: 2, marginBottom: 10 }}>
                    <div style={{ fontSize: 15, fontWeight: 700, color: "#fff", marginBottom: 4 }}>
                      博创电商聚合登录系统
                      <span style={{ color: C.accent, fontSize: 12, marginLeft: 6 }}>开源版</span>
                      <span style={{ color: C.accent, fontSize: 12, marginLeft: 8 }}>v1.0.0</span>
                    </div>
                    <div>By: <span style={{ color: C.accent, fontWeight: 700 }}>25337519</span></div>
                    <div>运行环境：{isElectron ? "Electron 桌面版" : "Web 浏览器"}</div>
                    <div>支持平台：{PLATFORMS.map(p => p.name).join("、")}</div>
                  </div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 14 }}>
                    {PLATFORMS.map(p => (
                      <span key={p.id} style={{ fontSize: 12, padding: "3px 8px", borderRadius: 6, background: `${p.color}12`, color: p.color, border: `1px solid ${p.color}25` }}>
                        {p.icon} {p.name}
                      </span>
                    ))}
                  </div>
                  <div style={{ padding: "12px 14px", background: C.surface2, borderRadius: 8, border: `1px solid ${C.border}` }}>
                    <div style={{ fontSize: 12, color: C.textMute, marginBottom: 10, fontWeight: 700, letterSpacing: 0.5 }}>📬 需要定制其它功能请联系</div>
                    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <div style={{ width: 32, height: 32, borderRadius: 8, background: "#1890FF18", border: "1px solid #1890FF30", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>🐧</div>
                        <div>
                          <div style={{ fontSize: 11, color: C.textMute }}>QQ</div>
                          <div style={{ fontSize: 14, color: "#1890FF", fontWeight: 700, letterSpacing: 1 }}>25337519</div>
                        </div>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <div style={{ width: 32, height: 32, borderRadius: 8, background: "#22c55e18", border: "1px solid #22c55e30", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>💬</div>
                        <div>
                          <div style={{ fontSize: 11, color: C.textMute }}>微信</div>
                          <div style={{ fontSize: 14, color: "#22c55e", fontWeight: 700, letterSpacing: 1 }}>EveryDadday135</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
            </div>
          )}
        </div>
      </div>

      {/* 删除确认弹窗 */}
      {deleteConfirmId && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.65)", backdropFilter: "blur(4px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 999 }}
          onClick={() => setDeleteConfirmId(null)}>
          <div style={{ background: C.surface, borderRadius: 16, border: `1px solid ${C.border2}`, padding: 28, width: 360, boxShadow: "0 20px 60px rgba(0,0,0,0.5)" }}
            onClick={e => e.stopPropagation()}>
            <div style={{ fontSize: 36, textAlign: "center", marginBottom: 10 }}>⚠️</div>
            <div style={{ fontSize: 16, fontWeight: 700, color: "#fff", textAlign: "center", marginBottom: 8 }}>确认删除账号？</div>
            <div style={{ fontSize: 13, color: C.textMute, textAlign: "center", marginBottom: 22 }}>删除后将无法恢复，该账号的登录信息将被清除。</div>
            <div style={{ display: "flex", gap: 10 }}>
              <button style={{ ...btn.ghost, flex: 1 }} onClick={() => setDeleteConfirmId(null)}>取消</button>
              <button style={{ ...btn.danger, flex: 1 }} onClick={() => handleDelete(deleteConfirmId)}>确认删除</button>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div style={{ position: "fixed", bottom: 28, left: "50%", transform: "translateX(-50%)", background: toast.type === "error" ? "#ef4444" : toast.type === "info" ? C.surface2 : "#16a34a", color: "#fff", padding: "11px 22px", borderRadius: 30, fontSize: 13, fontWeight: 600, boxShadow: "0 8px 30px rgba(0,0,0,0.4)", zIndex: 9999, whiteSpace: "nowrap", animation: "slideUp 0.25s ease" }}>
          {toast.msg}
        </div>
      )}
    </div>
  );
}
